//
//  StorageService.h
//  StorageService
//
//  Created by Ковалев Никита on 22.01.2024.
//

#import <Foundation/Foundation.h>

//! Project version number for StorageService.
FOUNDATION_EXPORT double StorageServiceVersionNumber;

//! Project version string for StorageService.
FOUNDATION_EXPORT const unsigned char StorageServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StorageService/PublicHeader.h>


