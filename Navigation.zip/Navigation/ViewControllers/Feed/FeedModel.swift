//import UIKit
//import Foundation
//
//class FeedModel {
//    
//    let secretWord = "Word"
//    
//    func check(word: String) -> Bool {
//         word == secretWord
//    }
//}
