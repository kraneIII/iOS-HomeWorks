import Foundation
import UIKit


public struct Post {
   public var title: String
    public init(title: String) {
        self.title = title
    }
}
