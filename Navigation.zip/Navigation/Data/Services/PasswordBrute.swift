import UIKit
import Foundation

class PasswordBrute {
    
}
